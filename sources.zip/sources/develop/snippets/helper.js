module.exports = {
  breakfast: "eggs and sausage, and a side of toast",
  // the following tests that Truffle injected vars are available here
  twoAccounts: accounts[0] + accounts[1]
}
