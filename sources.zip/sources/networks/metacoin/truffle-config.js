module.exports = {
  networks: {
    rinkyDink: {
      host: "127.0.0.1",
      port: "9545",
      network_id: 4
    }
  }
};
