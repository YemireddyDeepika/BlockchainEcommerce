module.exports = {
  genesis_time: new Date()
};
