module.exports = {
  genesis_time: "1/33/18"
};
